#!/usr/bin/env bash

source ~/viwistar_gui/devel/setup.bash

rosrun test_gui test_gui


